import React,{Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
// import results from './api.randomuser.me.js';
// import Card from './card.js'

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      results:[]
    }
  }
  componentDidMount() {
    fetch('https://api.randomuser.me')
      .then(res => {return res.json();})
      .then(json => {
        this.setState({
          results: json,    })
      });
  }
  render() {

  const { results } = this.state;   
   
    return (
      <div >
        {results.map((result) =>( 
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{result.name}</h5>
                  <img src="{result.picture.large}" alt="" />
                </div>
              </div>
           ))}
      </div>
    )
  }
}

export default App;